package com.example.notesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class AddNote extends AppCompatActivity {
    private EditText editTextTitle;
    private EditText editTextDescription;
    private Spinner spinnerDays;
    private RadioGroup radioGroupPriority;
    private NotesDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);
        database = NotesDatabase.getInstance(this);
        editTextTitle =findViewById(R.id.editTextTitle);
        editTextDescription =findViewById(R.id.editTextDescription);
        spinnerDays = findViewById(R.id.spinnerDays);
        radioGroupPriority = findViewById(R.id.radioGroup);

    }

    public void onClickAddItemToNote(View view) {
        String title = editTextTitle.getText().toString().trim();
        String description = editTextDescription.getText().toString().trim();
        int day = spinnerDays.getSelectedItemPosition();
        int buttonId = radioGroupPriority.getCheckedRadioButtonId();
        RadioButton radioButton = findViewById(buttonId);
        int priority = Integer.parseInt(radioButton.getText().toString());
        if (isFilled(title,description)) {
            Notes note = new Notes(title,description,day,priority);
            database.notesDao().insertNote(note);
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }else Toast.makeText(this, R.string.warning_fill_all_fields, Toast.LENGTH_SHORT).show();
    }

    private boolean isFilled(String title,String description){
        return !title.isEmpty() && !description.isEmpty();
    }
}