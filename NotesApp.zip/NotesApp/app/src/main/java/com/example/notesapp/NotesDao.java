package com.example.notesapp;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;

@Dao
public interface NotesDao {
    @Query("SELECT * FROM notes ORDER BY day")
    List<Notes> getAllNotes();

    @Insert
    void insertNote(Notes note);

    @Delete
    void deleteNote(Notes note);

    @Query("DELETE FROM notes")
    void deleteAll();
}
